// src/lib/crypto/identity.ts
"use client";

import sodium from "libsodium-wrappers-sumo";

let sodiumReady: Promise<typeof sodium> | null = null;

async function getSodium() {
  if (!sodiumReady) {
    sodiumReady = (async () => {
      await sodium.ready;
      return sodium;
    })();
  }
  return sodiumReady;
}

export interface CryptoIdentity {
  codename: string;
  publicKey: string; // base64 (URLSAFE)
  secretKey: string; // base64 (URLSAFE) - keep only on client
}

const IDENTITY_KEY = "e2ee_identity_v1";

export async function generateCryptoIdentity(
  codename: string
): Promise<CryptoIdentity> {
  const s = await getSodium();

  const { publicKey, privateKey } = s.crypto_box_keypair();

  const publicKeyB64 = s.to_base64(
    publicKey,
    s.base64_variants.URLSAFE_NO_PADDING
  );
  const secretKeyB64 = s.to_base64(
    privateKey,
    s.base64_variants.URLSAFE_NO_PADDING
  );

  const identity: CryptoIdentity = {
    codename,
    publicKey: publicKeyB64,
    secretKey: secretKeyB64,
  };

  if (typeof window !== "undefined") {
    window.localStorage.setItem(IDENTITY_KEY, JSON.stringify(identity));
  }

  return identity;
}

export function loadIdentity(): CryptoIdentity | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.localStorage.getItem(IDENTITY_KEY);
    if (!raw) return null;
    return JSON.parse(raw) as CryptoIdentity;
  } catch {
    return null;
  }
}

export function saveIdentity(identity: CryptoIdentity) {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(IDENTITY_KEY, JSON.stringify(identity));
}

export function clearIdentity() {
  if (typeof window === "undefined") return;
  window.localStorage.removeItem(IDENTITY_KEY);
}
