// src/lib/contacts/store.ts
"use client";

import { deriveSessionKey } from "@/lib/crypto/session";
import type { CryptoIdentity } from "@/lib/crypto/identity";

export interface Contact {
  id: string;
  codename: string;
  publicKey: string; // base64
  sharedKey?: string; // derived locally
}

const CONTACTS_KEY = "e2ee_contacts_v1";

export function loadContacts(): Contact[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = localStorage.getItem(CONTACTS_KEY);
    if (!raw) return [];
    return JSON.parse(raw) as Contact[];
  } catch {
    return [];
  }
}

export function saveContacts(contacts: Contact[]) {
  if (typeof window !== "undefined") {
    localStorage.setItem(CONTACTS_KEY, JSON.stringify(contacts));
  }
}

export async function addContact(
  me: CryptoIdentity,
  codename: string,
  theirPublicKey: string
): Promise<Contact> {
  const shared = await deriveSessionKey(me.secretKey, theirPublicKey);

  const newContact: Contact = {
    id: crypto.randomUUID(),
    codename,
    publicKey: theirPublicKey,
    sharedKey: shared.key,
  };

  const existing = loadContacts();
  const updated = [...existing, newContact];
  saveContacts(updated);

  return newContact;
}

export function clearContacts() {
  if (typeof window === "undefined") return;
  localStorage.removeItem(CONTACTS_KEY);
}
