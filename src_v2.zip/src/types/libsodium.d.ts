// src/types/libsodium.d.ts
declare module "libsodium-wrappers-sumo";
