// src/lib/identities/store.ts
"use client";

import {
  CryptoIdentity,
  generateCryptoIdentity,
} from "@/lib/crypto/identity";

export interface StoredIdentity extends CryptoIdentity {
  id: string;
  createdAt: string;
  lastActiveAt: string;
}

const IDS_KEY = "e2ee_identities_v1";
const ACTIVE_ID_KEY = "e2ee_active_identity_v1";

function loadAllIdentities(): StoredIdentity[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(IDS_KEY);
    if (!raw) return [];
    return JSON.parse(raw) as StoredIdentity[];
  } catch {
    return [];
  }
}

function saveAllIdentities(ids: StoredIdentity[]) {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(IDS_KEY, JSON.stringify(ids));
}

export function loadIdentities(): StoredIdentity[] {
  return loadAllIdentities();
}

export function getActiveIdentityId(): string | null {
  if (typeof window === "undefined") return null;
  return window.localStorage.getItem(ACTIVE_ID_KEY);
}

export function setActiveIdentityId(id: string | null) {
  if (typeof window === "undefined") return;
  if (id) {
    window.localStorage.setItem(ACTIVE_ID_KEY, id);
  } else {
    window.localStorage.removeItem(ACTIVE_ID_KEY);
  }
}

export async function createIdentity(
  codename: string
): Promise<StoredIdentity> {
  const base: CryptoIdentity = await generateCryptoIdentity(codename);
  const now = new Date().toISOString();

  const record: StoredIdentity = {
    id: crypto.randomUUID(),
    createdAt: now,
    lastActiveAt: now,
    ...base,
  };

  const existing = loadAllIdentities();
  const updated = [...existing, record];
  saveAllIdentities(updated);
  setActiveIdentityId(record.id);

  return record;
}

export function updateIdentityLastActive(id: string) {
  const all = loadAllIdentities();
  const idx = all.findIndex((i) => i.id === id);
  if (idx === -1) return;
  all[idx] = {
    ...all[idx],
    lastActiveAt: new Date().toISOString(),
  };
  saveAllIdentities(all);
}

export function getActiveIdentity(): StoredIdentity | null {
  const ids = loadAllIdentities();
  const activeId = getActiveIdentityId();
  if (!activeId) return null;
  return ids.find((i) => i.id === activeId) ?? null;
}

/** 🔥 NEW: delete identity (vault-level only) */
export function deleteIdentity(id: string) {
  const all = loadAllIdentities();
  const filtered = all.filter((i) => i.id !== id);
  saveAllIdentities(filtered);

  const activeId = getActiveIdentityId();
  if (activeId === id) {
    setActiveIdentityId(null);
  }
}
